/**
 * 
 */
$(document).ready(function(){
	$('.slider').bxSlider();
});
  
  
function chkDel() {
	return confirm("정말 리뷰를 삭제 하시겠습니까?");
}