package model.review;

import java.sql.Timestamp;
import java.util.*;

public class ReviewDto {
	
	private String writer;
	private int score;
	
	private Timestamp regdate;
	
	private String content;
	private String pro_no;
	
	private String review_id;
	private String pro_name;


	public ReviewDto() {}
	
//========================getter, setter===================================
	public String getWriter() {
		return writer;
	}

	public String getPro_name() {
		return pro_name;
	}

	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Timestamp getRegdate() {
		return regdate;
	}

	public void setRegdate(Timestamp regdate) {
		this.regdate = regdate;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPro_no() {
		return pro_no;
	}

	public void setPro_no(String pro_no) {
		this.pro_no = pro_no;
	}

	public String getReview_id() {
		return review_id;
	}

	public void setReview_id(String review_id) {
		this.review_id = review_id;
	}
	
	

}
