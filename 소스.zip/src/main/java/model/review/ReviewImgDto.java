package model.review;

public class ReviewImgDto {
	
	private String img_id;
	private int img_lvl;
	private String img_name;
	
	public ReviewImgDto() {}
	
//========================getter, setter===================================
	public String getImg_id() {
		return img_id;
	}
	public void setImg_id(String img_id) {
		this.img_id = img_id;
	}
	public int getImg_lvl() {
		return img_lvl;
	}
	public void setImg_lvl(int img_lvl) {
		this.img_lvl = img_lvl;
	}
	public String getImg_name() {
		return img_name;
	}
	public void setImg_name(String img_name) {
		this.img_name = img_name;
	}
	
	

}
